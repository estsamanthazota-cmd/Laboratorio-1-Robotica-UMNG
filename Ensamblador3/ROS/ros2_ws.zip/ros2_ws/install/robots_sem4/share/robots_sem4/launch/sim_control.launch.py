from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction, SetEnvironmentVariable
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg_robots = get_package_share_directory('robots_sem4')
    urdf_file = os.path.join(pkg_robots, 'urdf', 'Ensamblaje1.urdf')

    with open(urdf_file, "r") as f:
        robot_description_content = f.read()

    current_ld_library_path = os.environ.get("LD_LIBRARY_PATH", "")
    current_gz_plugin_path = os.environ.get("GZ_SIM_SYSTEM_PLUGIN_PATH", "")

    new_ld_library_path = "/opt/ros/jazzy/lib"
    if current_ld_library_path:
        new_ld_library_path += ":" + current_ld_library_path

    new_gz_plugin_path = "/opt/ros/jazzy/lib"
    if current_gz_plugin_path:
        new_gz_plugin_path += ":" + current_gz_plugin_path

    return LaunchDescription([
        SetEnvironmentVariable("ROS_DOMAIN_ID", "0"),
        SetEnvironmentVariable("ROS_AUTOMATIC_DISCOVERY_RANGE", "LOCALHOST"),
        SetEnvironmentVariable("LD_LIBRARY_PATH", new_ld_library_path),
        SetEnvironmentVariable("GZ_SIM_SYSTEM_PLUGIN_PATH", new_gz_plugin_path),

        # 1. Iniciar Gazebo Sim
        ExecuteProcess(
            cmd=["gz", "sim", "-r", "empty.sdf"],
            output="screen"
        ),

        # 2. Publicador del estado del robot (con tiempo de simulación)
        Node(
            package="robot_state_publisher",
            executable="robot_state_publisher",
            parameters=[{
                "robot_description": robot_description_content,
                "use_sim_time": True
            }],
            output="screen"
        ),

        # 3. Puente del reloj de Gazebo a ROS 2
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
            output='screen'
        ),

        # 4. Cargar el robot en Gazebo (a los 3 segundos)
        TimerAction(
            period=3.0,
            actions=[
                ExecuteProcess(cmd=[
                    "ros2", "run", "ros_gz_sim", "create",
                    "-world", "empty", "-file", urdf_file,
                    "-name", "ensamblaje1", "-z", "0.05"
                ], output="screen")
            ]
        ),

        # 5. Cargar joint_state_broadcaster (a los 8 segundos)
        TimerAction(
            period=8.0,
            actions=[
                ExecuteProcess(cmd=[
                    "ros2", "run", "controller_manager", "spawner",
                    "joint_state_broadcaster", "-c", "/controller_manager",
                    "--switch-timeout", "20"
                ], output="screen")
            ]
        ),

        # 6. Cargar arm_position_controller (a los 12 segundos)
        TimerAction(
            period=12.0,
            actions=[
                ExecuteProcess(cmd=[
                    "ros2", "run", "controller_manager", "spawner",
                    "arm_position_controller", "-c", "/controller_manager",
                    "--switch-timeout", "20"
                ], output="screen")
            ]
        ),

        # 7. Ejecutar tu GUI de Python (a los 15 segundos)
        TimerAction(
            period=15.0,
            actions=[
                Node(
                    package='robots_sem4',
                    executable='gui_sliders_robot.py',
                    output='screen'
                )
            ]
        )
    ])
