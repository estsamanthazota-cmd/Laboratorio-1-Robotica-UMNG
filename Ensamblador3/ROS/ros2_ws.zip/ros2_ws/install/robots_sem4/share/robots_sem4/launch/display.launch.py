import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, Command, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():

    # Ruta por defecto: SCARA (puedes cambiarla si quieres)
    default_model = PathJoinSubstitution([
        FindPackageShare('robots_sem4'),
        'urdf',
        'scara_rrp.urdf'
    ])

    model_arg = DeclareLaunchArgument(
        name='model',
        default_value=default_model,
        description='Absolute path to robot URDF file'
    )

    gui_arg = DeclareLaunchArgument(
        name='gui',
        default_value='True',
        description='Use joint_state_publisher_gui'
    )

    # Lee el URDF como texto (muy robusto)
    robot_description = ParameterValue(
        Command(['cat ', LaunchConfiguration('model')]),
        value_type=str
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description}],
        output='screen'
    )

    joint_state_publisher_gui = Node(
        package='joint_state_publisher_gui',
        executable='joint_state_publisher_gui',
        output='screen'
    )

    rviz2 = Node(
        package='rviz2',
        executable='rviz2',
        output='screen'
    )
    static_tf = Node(
    package='tf2_ros',
    executable='static_transform_publisher',
    arguments=['0.2', '0.74', '0.0', '0', '0', '0', 'map', 'base_link']
    )

    return LaunchDescription([
        model_arg,
        gui_arg,
        joint_state_publisher_gui,
        robot_state_publisher,
        rviz2
    ])
