#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

from tf2_ros import Buffer, TransformListener, TransformException


class RobotSliderGUI(Node):
    def __init__(self):
        super().__init__('robot_slider_gui')

        self.publisher_ = self.create_publisher(
            Float64MultiArray,
            '/arm_position_controller/commands',
            10
        )

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.current_values = [0.0, 0.0, 0.0]
        self.slider_widgets = []
        self.slider_value_labels = []

        self.root = tk.Tk()
        self.root.title('Control Robot 3DOF')
        self.root.geometry('620x560')
        self.root.minsize(580, 520)
        self.root.resizable(True, True)

        main_frame = ttk.Frame(self.root, padding=15)
        main_frame.pack(fill='both', expand=True)

        title = ttk.Label(
            main_frame,
            text='Control de articulaciones',
            font=('Arial', 16, 'bold')
        )
        title.pack(pady=(0, 12))

        self._create_slider(
            parent=main_frame,
            name='j1',
            min_val=-2.62,
            max_val=2.62,
            initial=0.0,
            index=0
        )

        self._create_slider(
            parent=main_frame,
            name='J2',
            min_val=-1.57,
            max_val=1.57,
            initial=0.0,
            index=1
        )

        self._create_slider(
            parent=main_frame,
            name='J3',
            min_val=-2.36,
            max_val=0.0,
            initial=0.0,
            index=2
        )

        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', pady=16)

        send_button = ttk.Button(
            button_frame,
            text='Enviar',
            command=self.publish_values
        )
        send_button.pack(side='left', padx=8)

        home_button = ttk.Button(
            button_frame,
            text='Home',
            command=self.go_home
        )
        home_button.pack(side='left', padx=8)

        close_button = ttk.Button(
            button_frame,
            text='Cerrar',
            command=self.close_app
        )
        close_button.pack(side='right', padx=8)

        ee_frame = ttk.LabelFrame(
            main_frame,
            text='Posición efector final',
            padding=10
        )
        ee_frame.pack(fill='x', pady=10)

        self.x_label = ttk.Label(ee_frame, text='X: --', font=('Arial', 11))
        self.x_label.pack(anchor='w', pady=2)

        self.y_label = ttk.Label(ee_frame, text='Y: --', font=('Arial', 11))
        self.y_label.pack(anchor='w', pady=2)

        self.z_label = ttk.Label(ee_frame, text='Z: --', font=('Arial', 11))
        self.z_label.pack(anchor='w', pady=2)

        self.status_label = ttk.Label(
            ee_frame,
            text='Frame: base_link → J3_Link',
            font=('Arial', 10)
        )
        self.status_label.pack(anchor='w', pady=(6, 0))

        info_label = ttk.Label(
            main_frame,
            text='Los valores articulares están en radianes.',
            font=('Arial', 10)
        )
        info_label.pack(pady=(8, 0))

        self.root.protocol("WM_DELETE_WINDOW", self.close_app)

        self.root.after(20, self.update_ros)
        self.root.after(150, self.update_ee_pose)

    def _create_slider(self, parent, name, min_val, max_val, initial, index):
        frame = ttk.LabelFrame(parent, text=name, padding=8)
        frame.pack(fill='x', padx=4, pady=8)

        value_label = ttk.Label(frame, text=f'{initial:.3f} rad', font=('Arial', 10))
        value_label.pack(anchor='e')
        self.slider_value_labels.append(value_label)

        slider = tk.Scale(
            frame,
            from_=min_val,
            to=max_val,
            orient='horizontal',
            resolution=0.01,
            length=500,
            sliderlength=24,
            command=lambda value, idx=index: self.on_slider_change(idx, value)
        )
        slider.set(initial)
        slider.pack(fill='x', expand=True)

        self.slider_widgets.append(slider)

    def on_slider_change(self, index, value):
        self.current_values[index] = float(value)
        self.slider_value_labels[index].config(
            text=f'{float(value):.3f} rad'
        )

    def publish_values(self):
        msg = Float64MultiArray()
        msg.data = list(self.current_values)
        self.publisher_.publish(msg)
        self.get_logger().info(f'Enviado: {self.current_values}')

    def go_home(self):
        home_values = [0.0, 0.0, 0.0]

        for i, value in enumerate(home_values):
            self.slider_widgets[i].set(value)
            self.current_values[i] = value
            self.slider_value_labels[i].config(text=f'{value:.3f} rad')

        self.publish_values()

    def update_ee_pose(self):
        try:
            transform = self.tf_buffer.lookup_transform(
                'base_link',
                'J3_Link',
                rclpy.time.Time()
            )

            x = transform.transform.translation.x
            y = transform.transform.translation.y
            z = transform.transform.translation.z

            self.x_label.config(text=f'X: {x:.4f} m')
            self.y_label.config(text=f'Y: {y:.4f} m')
            self.z_label.config(text=f'Z: {z:.4f} m')
            self.status_label.config(text='Frame: base_link → J3_Link')

        except TransformException:
            self.x_label.config(text='X: --')
            self.y_label.config(text='Y: --')
            self.z_label.config(text='Z: --')
            self.status_label.config(
                text='No se pudo leer TF base_link → J3_Link'
            )

        self.root.after(150, self.update_ee_pose)

    def update_ros(self):
        rclpy.spin_once(self, timeout_sec=0.01)
        self.root.after(20, self.update_ros)

    def close_app(self):
        self.destroy_node()
        rclpy.shutdown()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    rclpy.init()
    app = RobotSliderGUI()
    app.run()


if __name__ == '__main__':
    main()
