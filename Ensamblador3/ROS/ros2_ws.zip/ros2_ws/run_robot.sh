#!/bin/bash

source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash

gnome-terminal -- bash -c "source /opt/ros/jazzy/setup.bash; source ~/ros2_ws/install/setup.bash; ros2 launch robots_sem4 sim_control.launch.py; exec bash"

sleep 8

gnome-terminal -- bash -c "source /opt/ros/jazzy/setup.bash; source ~/ros2_ws/install/setup.bash; ros2 topic pub --once /arm_position_controller/commands std_msgs/msg/Float64MultiArray \"{data: [0.0, 0.0, 0.0]}\"; exec bash"

sleep 2

gnome-terminal -- bash -c "source /opt/ros/jazzy/setup.bash; source ~/ros2_ws/install/setup.bash; python3 ~/ros2_ws/src/robots_sem4/scripts/gui_sliders_robot.py; exec bash"
