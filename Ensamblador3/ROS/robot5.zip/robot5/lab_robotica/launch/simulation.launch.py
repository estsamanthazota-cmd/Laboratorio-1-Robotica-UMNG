import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    IncludeLaunchDescription,
    TimerAction,
    LogInfo,
    SetEnvironmentVariable,
)
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = 'lab_robotica'

    # 1. URDF
    urdf_file = '/home/nicolas-acosta/robotics/src/lab_robotica/urdf/robot_5.urdf'
    with open(urdf_file, 'r') as infp:
        robot_description_content = infp.read()
    robot_description = {'robot_description': robot_description_content}

    # 2. Meshes visibles para Gazebo
    resource_path = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value='/home/nicolas-acosta/robotics/install/lab_robotica/share'
    )

    # 3. Robot State Publisher
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description, {'use_sim_time': True}]
    )

    # 4. Gazebo
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([os.path.join(
            get_package_share_directory('ros_gz_sim'),
            'launch', 'gz_sim.launch.py')]),
        launch_arguments={
            'gz_args': '-r -v 3 empty.sdf',
        }.items()
    )

    # 5. Spawn del robot con delay para evitar race condition
    spawn_entity = TimerAction(
        period=5.0,
        actions=[
            LogInfo(msg='[launch] Gazebo listo — spawneando robot_5...'),
            Node(
                package='ros_gz_sim',
                executable='create',
                arguments=[
                    '-topic', 'robot_description',
                    '-name', 'robot_5',
                    '-z', '0.1',
                ],
                output='screen'
            )
        ]
    )

    # 6. Activar controladores después del spawn
    load_joint_state_broadcaster = TimerAction(
        period=8.0,
        actions=[
            LogInfo(msg='[launch] Activando joint_state_broadcaster...'),
            Node(
                package='controller_manager',
                executable='spawner',
                arguments=['joint_state_broadcaster',
                           '--controller-manager', '/controller_manager'],
                output='screen'
            )
        ]
    )

    load_arm_position_controller = TimerAction(
        period=9.0,
        actions=[
            LogInfo(msg='[launch] Activando arm_position_controller...'),
            Node(
                package='controller_manager',
                executable='spawner',
                arguments=['arm_position_controller',
                           '--controller-manager', '/controller_manager'],
                output='screen'
            )
        ]
    )

    load_arm_velocity_controller = TimerAction(
        period=10.0,
        actions=[
            LogInfo(msg='[launch] Activando arm_velocity_controller...'),
            Node(
                package='controller_manager',
                executable='spawner',
                arguments=['arm_velocity_controller',
                           '--controller-manager', '/controller_manager'],
                output='screen'
            )
        ]
    )

    # 7. Nodos propios con inyección de use_sim_time
    reader_node = Node(
        package=package_name,
        executable='trajectory_reader',
        name='reader',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    sim_pub_node = Node(
        package=package_name,
        executable='sim_publisher',
        name='sim_publisher',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    server_node = Node(
        package=package_name,
        executable='robot_server',
        name='action_server',
        output='screen',
        parameters=[{'use_sim_time': True}]
    )

    test_client_node = Node(
        package=package_name,
        executable='test_client',
        name='test_client',
        output='screen',
        emulate_tty=True,
        additional_env={'PYTHONUNBUFFERED': '1'},
        parameters=[{'use_sim_time': True}]
    )

    # 8. Puente fundamental para el reloj de Gazebo hacia ROS 2
    clock_bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        arguments=['/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock'],
        output='screen'
    )

    return LaunchDescription([
        resource_path,
        node_robot_state_publisher,
        gazebo,
        spawn_entity,
        load_joint_state_broadcaster,
        load_arm_position_controller,
        load_arm_velocity_controller,
        reader_node,
        sim_pub_node,
        server_node,
        test_client_node,
        clock_bridge
    ])