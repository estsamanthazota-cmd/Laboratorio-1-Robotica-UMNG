import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, Bool
from ament_index_python.packages import get_package_share_directory
import os

class TrajectoryReader(Node):
    def __init__(self):
        super().__init__('trajectory_reader_node')
        # NOTA: Ya no declaramos 'use_sim_time' aquí para evitar el crasheo.
        # ROS 2 lo inyectará automáticamente desde el Launch.
        
        self.publisher_ = self.create_publisher(Float64MultiArray, 'raw_points', 10)
        self.finish_pub = self.create_publisher(Bool, 'task_finished_internal', 10)
        
        self.subscription = self.create_subscription(
            Float64MultiArray, 'load_task', self.load_task_callback, 10)
        
        self.package_share_directory = get_package_share_directory('lab_robotica')

    def load_task_callback(self, msg):
        task_id = int(msg.data[0])
        
        if task_id == 0:
            self.get_logger().info('INICIANDO MODO BATCH: Procesando 20 trayectorias...')
            tasks = range(1, 21)
        else:
            tasks = [task_id]

        # Usamos los Timers nativos de ROS 2 en lugar de time.sleep()
        rate_50hz = self.create_rate(50.0)
        rate_pause = self.create_rate(10.0) 

        for current_id in tasks:
            file_path = os.path.join(self.package_share_directory, 'trajectories', f'T{current_id}.txt')
            
            if not os.path.exists(file_path):
                self.get_logger().error(f'Archivo no encontrado: {file_path}')
                continue

            self.get_logger().info(f'Ejecutando: T{current_id}.txt')

            with open(file_path, 'r') as f:
                for line in f:
                    data = line.split()
                    if len(data) >= 4:
                        point = Float64MultiArray()
                        point.data = [float(data[1]), float(data[2]), float(data[3])]
                        self.publisher_.publish(point)
                        rate_50hz.sleep() 
            
            rate_pause.sleep()

        finish_msg = Bool()
        finish_msg.data = True
        self.finish_pub.publish(finish_msg)
        self.get_logger().info('Secuencia de tareas finalizada exitosamente.')

def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryReader()
    rclpy.spin(node)
    rclpy.shutdown()