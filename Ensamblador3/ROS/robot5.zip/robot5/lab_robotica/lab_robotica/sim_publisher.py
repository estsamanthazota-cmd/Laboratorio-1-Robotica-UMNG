import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class SimPublisher(Node):
    def __init__(self):
        super().__init__('sim_publisher_node')
        
        self.subscription = self.create_subscription(
            Float64MultiArray, 'raw_points', self.listener_callback, 10)
        
        # Tópico relativo, emparejado con controllers.yaml
        self.publisher_ = self.create_publisher(
            Float64MultiArray, 'arm_position_controller/commands', 10)
        
        self.get_logger().info("Nodo de simulación listo. Publicando en arm_position_controller/commands")

    def listener_callback(self, msg):
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SimPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()