import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node
from planta_interfaces.action import ExecuteTrajectory
from std_msgs.msg import Float64MultiArray, Bool
import time
import asyncio

class RobotServer(Node):
    def __init__(self):
        super().__init__('robot_server_node')
        self._action_server = ActionServer(
            self, ExecuteTrajectory, 'execute_trajectory', self.execute_callback)
        
        self.task_pub = self.create_publisher(Float64MultiArray, 'load_task', 10)
        self.finish_sub = self.create_subscription(
            Bool, 'task_finished_internal', self.finish_cb, 10)
        
        self.task_done = False
        self.get_logger().info('Servidor de Acción Operativo (Modo Integración).')

    def finish_cb(self, msg):
        if msg.data:
            self.task_done = True

    async def execute_callback(self, goal_handle):
        self.get_logger().info('Nueva solicitud de trayectoria recibida.')
        start_time = time.time()
        task_id = goal_handle.request.task_id
        self.task_done = False
        
        # 1. Enviar comando al lector
        msg = Float64MultiArray()
        msg.data = [float(task_id)]
        self.task_pub.publish(msg)
        
        feedback_msg = ExecuteTrajectory.Feedback()
        
        # 2. Bucle de espera no bloqueante usando asyncio (Cede control a ROS 2)
        while not self.task_done:
            feedback_msg.percentage = 0.0 
            feedback_msg.safety_ok = True
            goal_handle.publish_feedback(feedback_msg)
            await asyncio.sleep(0.5) 

        # 3. Respuesta final
        duration = time.time() - start_time
        goal_handle.succeed()
        
        result = ExecuteTrajectory.Result()
        result.success = True
        result.execution_time = float(duration)
        self.get_logger().info(f'Acción finalizada. Tiempo total: {duration:.2f}s')
        
        return result

def main(args=None):
    rclpy.init(args=args)
    node = RobotServer()
    rclpy.spin(node)
    rclpy.shutdown()