import sys
import os
import time
import numpy as np
import re
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from tf2_ros import Buffer, TransformListener
from ament_index_python.packages import get_package_share_directory

from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QComboBox, QLabel, 
                             QRadioButton, QGroupBox)
from PySide6.QtCore import QThread, Signal, QTimer, Qt

class SequenceWorker(QThread):
    """Hilo para ejecutar los 21 archivos sin interrupciones"""
    finished = Signal()
    progress = Signal(str)

    def __init__(self, node, traj_path, use_velocity):
        super().__init__()
        self.node = node
        self.traj_path = traj_path
        self.use_velocity = use_velocity

    def run(self):
        # Función para extraer el número del nombre del archivo
        def natural_sort_key(s):
            return [int(text) if text.isdigit() else text.lower()
                    for text in re.split('([0-9]+)', s)]

        # Listar y ordenar de forma natural (1, 2, 3... 10, 11...)
        all_files = [f for f in os.listdir(self.traj_path) if f.endswith('.txt')]
        files = sorted(all_files, key=natural_sort_key)
        
        last_pos = [0.0, 0.0, 0.0]

        try:
            for file_name in files:
                self.progress.emit(f"Ejecutando: {file_name}")
                # Imprimimos en consola para que verifiques el orden
                print(f"DEBUG: Procesando archivo {file_name}")               
                data = np.loadtxt(os.path.join(self.traj_path, file_name))             
                for row in data:
                    msg = Float64MultiArray()
                    last_pos = row[1:4].tolist()
                    msg.data = last_pos
                    self.node.pub.publish(msg)
                    time.sleep(0.02)


                for _ in range(10):
                    m = Float64MultiArray()
                    m.data = last_pos
                    self.node.pub.publish(m)
                    time.sleep(0.005)

        except Exception as e:
            print(f"Error en secuencia: {e}")
        
        self.finished.emit()

class RobotNode(Node):
    def __init__(self):
        super().__init__('gui_robot_node')
        
        # OBLIGATORIO: Forzar el uso de tiempo de simulación en el nodo
        self.set_parameters([rclpy.parameter.Parameter('use_sim_time', rclpy.Parameter.Type.BOOL, True)])
        
        self.pub = self.create_publisher(Float64MultiArray, '/arm_position_controller/commands', 10)
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.node = RobotNode()
        self.setWindowTitle("UMNG Mechatronics - Dashboard")
        self.resize(400, 500)
        
        # Ruta de trayectorias
        pkg_share = get_package_share_directory('lab_robotica')
        self.traj_path = os.path.join(pkg_share, 'trajectories')

        self.init_ui()
        self.apply_styles()

        # Timer para actualizar la posición real desde el TF
        self.ui_timer = QTimer()
        self.ui_timer.timeout.connect(self.update_ee_position)
        self.ui_timer.start(50)

    def init_ui(self):
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # Monitor de Posición Real
        group_ee = QGroupBox("Posición Efector Final (TF)")
        ee_layout = QVBoxLayout()
        self.lbl_pos = QLabel("X: 0.000\nY: 0.000\nZ: 0.000")
        self.lbl_pos.setObjectName("monitor")
        self.lbl_pos.setAlignment(Qt.AlignCenter)
        ee_layout.addWidget(self.lbl_pos)
        group_ee.setLayout(ee_layout)
        layout.addWidget(group_ee)

        # Configuración de Control
        group_ctrl = QGroupBox("Tipo de Control")
        ctrl_layout = QHBoxLayout()
        self.rb_pos = QRadioButton("Posición")
        self.rb_pos.setChecked(True)
        self.rb_vel = QRadioButton("Velocidad")
        ctrl_layout.addWidget(self.rb_pos)
        ctrl_layout.addWidget(self.rb_vel)
        group_ctrl.setLayout(ctrl_layout)
        layout.addWidget(group_ctrl)

        # Status
        self.lbl_status = QLabel("Sistema listo")
        self.lbl_status.setAlignment(Qt.AlignCenter)
        self.lbl_status.setStyleSheet("color: #00ff00; font-weight: bold;")
        layout.addWidget(self.lbl_status)

        # Botón de Inicio
        self.btn_start = QPushButton("INICIAR SECUENCIA COMPLETA")
        self.btn_start.setMinimumHeight(60)
        self.btn_start.clicked.connect(self.start_sequence)
        layout.addWidget(self.btn_start)

        self.setCentralWidget(main_widget)
    def update_ee_position(self):
        """
        Obtiene la transformada del End Effector desde el TF Tree de ROS 2
        y actualiza las etiquetas de la interfaz gráfica.
        """
        try:

            now = rclpy.time.Time()
 
            trans = self.node.tf_buffer.lookup_transform(
                'world', 
                'end_effector_point', 
                now,
                timeout=rclpy.duration.Duration(seconds=0.05)
            )
 
            pos_x = trans.transform.translation.x
            pos_y = trans.transform.translation.y
            pos_z = trans.transform.translation.z
            

            self.lbl_pos.setText(f"X: {pos_x:.3f}\nY: {pos_y:.3f}\nZ: {pos_z:.3f}")
            
  
            self.lbl_pos.setStyleSheet("""
                font-family: 'Courier New'; 
                font-size: 24px; 
                color: #00FF00; 
                background-color: black; 
                border: 2px solid #333;
                padding: 5px;
            """)

        except Exception:
   
            self.lbl_pos.setText("Sincronizando...\n(Inicie Gazebo)")
            self.lbl_pos.setStyleSheet("color: yellow; background-color: black; font-size: 18px;")

    def start_sequence(self):
        self.btn_start.setEnabled(False)
        self.worker = SequenceWorker(self.node, self.traj_path, self.rb_vel.isChecked())
        self.worker.progress.connect(self.lbl_status.setText)
        self.worker.finished.connect(self.on_sequence_finished)
        self.worker.start()

    def on_sequence_finished(self):
        self.lbl_status.setText("Secuencia completada")
        self.btn_start.setEnabled(True)

    def apply_styles(self):
        self.setStyleSheet("""
            QMainWindow { background-color: #1e1e1e; }
            QGroupBox { color: #00d4ff; border: 2px solid #333; font-weight: bold; margin-top: 10px; }
            QLabel { color: white; }
            QPushButton { background-color: #d32f2f; color: white; font-weight: bold; border-radius: 8px; }
            QPushButton:hover { background-color: #f44336; }
        """)

def main():
    rclpy.init()
    app = QApplication(sys.argv)
    gui = MainWindow()
    gui.show()
    ros_timer = QTimer()
    ros_timer.timeout.connect(lambda: rclpy.spin_once(gui.node, timeout_sec=0))
    ros_timer.start(10)
    sys.exit(app.exec())

if __name__ == '__main__':
    main()