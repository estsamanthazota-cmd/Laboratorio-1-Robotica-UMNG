from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'lab_robotica'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
        (os.path.join('share', package_name, 'urdf'), glob('urdf/*')),
        (os.path.join('share', package_name, 'meshes'), glob('meshes/*')),
        (os.path.join('share', package_name, 'trajectories'), glob('trajectories/*.txt')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='nicolas-acosta',
    maintainer_email='est.nicolas.facosta@unimilitar.edu.co',
    description='Robot 5 - Secuenciador de trayectorias T1-T20 para planta de manufactura',
    license='Apache-2.0',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'robot_server = lab_robotica.robot_server:main',
            'trajectory_reader = lab_robotica.trajectory_reader:main',
            'sim_publisher = lab_robotica.sim_publisher:main',
            'test_client = lab_robotica.test_client:main',
        ],
    },
)
