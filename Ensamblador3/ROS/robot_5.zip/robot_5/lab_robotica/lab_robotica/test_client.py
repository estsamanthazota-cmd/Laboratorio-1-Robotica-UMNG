import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from planta_interfaces.action import ExecuteTrajectory

class DirectBurstClient(Node):
    def __init__(self):
        super().__init__('direct_burst_client')
        self._action_client = ActionClient(self, ExecuteTrajectory, 'execute_trajectory')

    def send_burst_order(self):
        self.get_logger().info('Esperando al servidor de acción...')
        self._action_client.wait_for_server()
        
        # Al no haber ventana externa, este prompt saldrá directo en tu terminal principal
        input("\n>>> [PRESIONA ENTER] para iniciar as 20 trayectorias... ")
        
        goal_msg = ExecuteTrajectory.Goal()
        goal_msg.task_id = 0 
        
        self.get_logger().info('¡Orden enviada con éxito! Despachando T1 a T20...')
        self._action_client.send_goal_async(goal_msg)

def main(args=None):
    rclpy.init(args=args)
    client = DirectBurstClient()
    client.send_burst_order()
    # Procesamos la comunicación un momento para asegurar el despacho del mensaje
    rclpy.spin_once(client, timeout_sec=2.0)
    print("Ráfaga en ejecución en los nodos de la planta.")

if __name__ == '__main__':
    main()