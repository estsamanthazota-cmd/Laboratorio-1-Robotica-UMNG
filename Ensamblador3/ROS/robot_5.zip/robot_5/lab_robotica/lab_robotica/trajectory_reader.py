import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray, Bool
from ament_index_python.packages import get_package_share_directory
import os
import time

class TrajectoryReader(Node):
    def __init__(self):
        super().__init__('trajectory_reader_node')
        # Publica los ángulos deseados (Espacio Articular)
        self.publisher_ = self.create_publisher(Float64MultiArray, 'raw_points', 10)
        # Notifica cuando termina la ráfaga
        self.finish_pub = self.create_publisher(Bool, 'task_finished_internal', 10)
        
        self.subscription = self.create_subscription(
            Float64MultiArray, 'load_task', self.load_task_callback, 10)
        
        self.package_share_directory = get_package_share_directory('lab_robotica')

    def load_task_callback(self, msg):
        task_id = int(msg.data[0])
        
        # Lógica de ráfaga: Si el ID es 0, recorre del 1 al 20.
        if task_id == 0:
            self.get_logger().info('INICIANDO MODO BATCH: Procesando 20 trayectorias...')
            tasks = range(1, 21)
        else:
            tasks = [task_id]

        for current_id in tasks:
            file_path = os.path.join(self.package_share_directory, 'trajectories', f'T{current_id}.txt')
            
            if not os.path.exists(file_path):
                self.get_logger().error(f'Archivo no encontrado: {file_path}')
                continue

            self.get_logger().info(f'Ejecutando: T{current_id}.txt')

            with open(file_path, 'r') as f:
                for line in f:
                    data = line.split()
                    if len(data) >= 4:
                        point = Float64MultiArray()
                        # Formato: ID, q1, q2, q3 (Espacio articular)
                        point.data = [float(data[1]), float(data[2]), float(data[3])]
                        self.publisher_.publish(point)
                        # Sincronización a 50Hz (20ms) para Gazebo y Control Manager
                        time.sleep(0.02) 
            
            # Pequeña pausa de seguridad entre archivos para que el controlador se estabilice
            time.sleep(0.1)

        # Una vez terminada toda la lista (sea 1 o 20), avisamos al servidor
        finish_msg = Bool()
        finish_msg.data = True
        self.finish_pub.publish(finish_msg)
        self.get_logger().info('Secuencia de tareas finalizada exitosamente.')

def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryReader()
    rclpy.spin(node)
    rclpy.shutdown()
