import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class SimPublisher(Node):
    def __init__(self):
        super().__init__('sim_publisher_node')
        
        # Suscribirse a los mismos puntos que van a la ESP32
        self.subscription = self.create_subscription(
            Float64MultiArray, 'raw_points', self.listener_callback, 10)
        
        # Tópico hacia el controlador de posición de ros2_control (Gazebo/RViz)
        self.publisher_ = self.create_publisher(
            Float64MultiArray, '/forward_position_controller/commands', 10)
        
        self.get_logger().info("Nodo de simulación listo y escuchando 'raw_points'")

    def listener_callback(self, msg):
        # Reenvía el mensaje tal cual a la simulación
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = SimPublisher()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
