import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
import serial
import numpy as np

class ESP32Bridge(Node):
    def __init__(self):
        super().__init__('esp32_bridge_node')
        # Parámetros DH (L1, L2, L3 según tu robot)
        self.L1, self.L2, self.L3 = 0.2, 0.2, 0.2 
        # Matriz de Ganancia K (Ajustable)
        self.K = np.diag([1.5, 1.5, 1.5]) 
        
        try:
            self.ser = serial.Serial('/dev/ttyUSB0', 115200, timeout=0.01)
            self.get_logger().info("Controlador Cinemático y Bridge Serial Iniciado.")
        except Exception as e:
            self.get_logger().error(f"Error Serial: {e}")

        # Recibe q1, q2, q3 del espacio de articulaciones
        self.subscription = self.create_subscription(
            Float64MultiArray, 'raw_points', self.control_callback, 10)
        
        self.q_actual = np.array([0.001, 0.0, 0.0]) # Feedback real de la ESP

    def dh_matrix(self, theta, d, a, alpha):
        return np.array([
            [np.cos(theta), -np.sin(theta)*np.cos(alpha),  np.sin(theta)*np.sin(alpha), a*np.cos(theta)],
            [np.sin(theta),  np.cos(theta)*np.cos(alpha), -np.cos(theta)*np.sin(alpha), a*np.sin(theta)],
            [0,              np.sin(alpha),               np.cos(alpha),              d],
            [0,              0,                           0,                          1]
        ])

    def forward_kinematics(self, q):
        T01 = self.dh_matrix(q[0], self.L1, 0, np.pi/2)
        T12 = self.dh_matrix(q[1], 0, self.L2, 0)
        T23 = self.dh_matrix(q[2], 0, self.L3, 0)
        T03 = T01 @ T12 @ T23
        return T03[:3, 3]

    def get_jacobian(self, q):
        # Jacobiano geométrico para posición (3x3)
        # Aquí implementas las derivadas o el método geométrico
        J = np.random.rand(3,3) # Espacio para tu matriz 3x3
        return J

    def control_callback(self, msg):
        # q deseado que viene del lector
        q_deseado = np.array(msg.data)
        
        # 1. Feedback de la ESP: Leer RPMs reales e integrar para obtener q_actual
        if self.ser.in_waiting > 0:
            line = self.ser.readline().decode('utf-8', errors='ignore').strip()
            # La ESP manda: ref, rpm1, rpm2, rpm3
            parts = line.split(',')
            if len(parts) >= 4:
                # Convertir RPM a Rad/s y luego integrar (Ts=0.05 en tu ESP)
                # q_actual += (rpm * (2*pi/60)) * Ts
                pass

        # 2. Convertir Deseado y Actual al Espacio de Trabajo (X, Y, Z)
        x_deseado = self.forward_kinematics(q_deseado)
        x_actual = self.forward_kinematics(self.q_actual)

        # 3. Error en espacio de trabajo
        error_x = x_deseado - x_actual

        # 4. Velocidad de Control (Tarea): V = K * error
        v_tarea = self.K @ error_x

        # 5. Jacobiano Inverso para volver a espacio de articulaciones
        J = self.get_jacobian(self.q_actual)
        q_dot = np.linalg.pinv(J) @ v_tarea # Rad/s

        # 6. Convertir a RPM (Unidades de tu ESP)
        rpm_out = q_dot * (60.0 / (2 * np.pi))

        # 7. Envío Serial: parseFloat() capturará v1,v2,v3
        data_str = f"{rpm_out[0]:.2f},{rpm_out[1]:.2f},{rpm_out[2]:.2f}\n"
        self.ser.write(data_str.encode('utf-8'))

def main(args=None):
    rclpy.init(args=args)
    node = ESP32Bridge()
    rclpy.spin(node)
    rclpy.shutdown()
