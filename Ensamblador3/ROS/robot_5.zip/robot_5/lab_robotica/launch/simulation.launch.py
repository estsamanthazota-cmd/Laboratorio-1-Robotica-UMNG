import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node

def generate_launch_description():
    package_name = 'lab_robotica'

    # 1. Leer el archivo URD puro con su nombre exacto
    urdf_file = os.path.join(get_package_share_directory(package_name), 'urdf', 'robot_5.urd')
    
    with open(urdf_file, 'r') as infp:
        robot_description_content = infp.read()
        
    robot_description = {'robot_description': robot_description_content}

    # 2. Nodo Robot State Publisher
    node_robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[robot_description]
    )

    # 3. Lanzar Gazebo Harmonic (Nativo de ROS 2 Jazzy)
    ros_gz_sim_dir = get_package_share_directory('ros_gz_sim')
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(ros_gz_sim_dir, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(), 
    )

    # 4. Spawner para inyectar tu modelo en Gazebo
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=['-string', robot_description_content, '-name', 'my_robot', '-x', '0', '-y', '0', '-z', '0.1'],
        output='screen'
    )

    # 5. Nodo: El Lector (Trajectory Reader)
    reader_node = Node(
        package=package_name,
        executable='trajectory_reader',
        name='reader',
        output='screen'
    )

    # 6. Nodo: El Publicador Sim (Sim Publisher)
    sim_pub_node = Node(
        package=package_name,
        executable='sim_publisher',
        name='sim_publisher',
        output='screen'
    )

    # 7. Nodo: El Servidor de Acción (Robot Server)
    server_node = Node(
        package=package_name,
        executable='robot_server',
        name='action_server',
        output='screen'
    )

    # 8. Nodo: El Cliente Disparador (Misma terminal)
    test_client_node = Node(
        package=package_name,
        executable='test_client',
        name='test_client',
        output='screen'
    )

    return LaunchDescription([
        gazebo_launch,
        node_robot_state_publisher,
        spawn_entity,
        reader_node,
        sim_pub_node,
        server_node,
        test_client_node
    ])